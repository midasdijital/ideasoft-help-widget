# Midas Dijital – IdeaSoft Help Popup

**Midas Dijital E-Ticaret Danışmanlık** tarafından geliştirilen, IdeaSoft altyapılı e-ticaret siteleri için özelleştirilebilir ve bağımlılıksız (Vanilla JS) yardım / destek popup bileşeni.

## Özellikler

- Masaüstünde modern yuvarlak yardım butonu
- Mobilde sol kenara yapışık, içerik alanını minimum kapatan kulakçık tasarımı
- WhatsApp destek entegrasyonu
- Kargo takip ve kampanya bağlantıları
- Otomatik açılan konuşma balonu
- Hariç tutulacak sayfalar (`/sepet`, `/odeme` vb.)
- Marka rengi, logo, metinler, bağlantılar ve konum ayarlanabilir
- Tek JS dosyası ile çalışır
- Müşteri bazında ayrı config ile yeniden kullanılabilir

## Geliştirici

**Midas Dijital E-Ticaret Danışmanlık**  
E-ticaret altyapıları, özel geliştirmeler ve dönüşüm odaklı kullanıcı deneyimi çözümleri.

## Klasör Yapısı

```text
ideasoft-help-popup/
├── src/
│   └── ideasoft-help-popup.js
├── config.example.js
├── README.md
└── LICENSE
```

## Kurulum

1. `config.example.js` dosyasını müşterinin/markanın bilgilerine göre düzenleyin.
2. Önce config dosyasını, ardından `src/ideasoft-help-popup.js` dosyasını IdeaSoft **Özel Kod / Footer JS** alanına ekleyin.
3. Kaydedin ve gerekiyorsa tema/uygulama önbelleğini temizleyin.

## Konfigürasyon

| Alan | Açıklama |
|---|---|
| `brandName` | Müşteri / marka adı |
| `title` | Yardım merkezi başlığı |
| `subtitle` | Başlık altı açıklama |
| `logoUrl` | Marka logosu URL'si |
| `primaryColor` | Ana marka rengi |
| `primaryColorDark` | Gradient ikinci rengi |
| `whatsappNumber` | Ülke kodlu WhatsApp numarası |
| `excludedPaths` | Widget'ın görünmeyeceği sayfalar |
| `bubbleDelay` | Balon açılma gecikmesi (ms) |
| `bubbleDuration` | Balon görünme süresi (ms) |
| `desktop` | Masaüstü konum ve genişlik ayarları |
| `mobile` | Mobil kulakçık ölçüleri ve konumu |
| `actions` | Menü bağlantıları |

## Mobil Kulakçık

```js
mobile: {
  left: 0,
  bottom: 95,
  width: 340,
  tabWidth: 42,
  tabHeight: 76
}
```

- `bottom`: Ekranın altından yükseklik
- `tabWidth`: Kapalı mobil kulakçığın genişliği
- `tabHeight`: Kapalı mobil kulakçığın yüksekliği

## Sayfa Gizleme

```js
excludedPaths: [
  "/sepet",
  "/sepet/",
  "/odeme"
]
```

Bu sayfalarda bileşen DOM'a eklenmez.

## Kullanım Notu

Ana JavaScript dosyasını değiştirmek yerine her proje için yalnızca config değerlerini düzenlemek önerilir. Böylece aynı Midas Dijital bileşeni farklı IdeaSoft mağazalarında marka bazında hızlıca kullanılabilir.

## Lisans

MIT License. Kaynak kod başlıklarında yer alan **Midas Dijital** geliştirici bilgisinin korunması önerilir.

---

Developed by **Midas Dijital E-Ticaret Danışmanlık**.
