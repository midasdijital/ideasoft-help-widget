/**
 * Midas Dijital - IdeaSoft Help Popup
 * Proje bazlı örnek yapılandırma dosyası.
 * Developed by Midas Dijital E-Ticaret Danışmanlık
 */

window.IDEASOFT_HELP_POPUP_CONFIG = {
  brandName: "Markanız",
  title: "Markanız Yardım Merkezi",
  subtitle: "Size nasıl yardımcı olabiliriz?",
  logoUrl: "https://alanadiniz.com/logo.png",
  primaryColor: "#dc2237",
  primaryColorDark: "#b91327",
  whatsappNumber: "905555555555",
  bubbleText: "Nasıl yardımcı olabiliriz?",
  welcomeText: "Sipariş, kargo ve destek işlemlerinize hızlıca ulaşın.",
  bubbleDelay: 3000,
  bubbleDuration: 5000,
  excludedPaths: ["/sepet", "/odeme"],
  desktop: { left: 24, bottom: 100, width: 340 },
  mobile: { left: 0, bottom: 95, width: 340, tabWidth: 42, tabHeight: 76 },
  actions: [
    { type: "whatsapp", icon: "💬", text: "WhatsApp Destek" },
    { type: "link", icon: "📦", text: "Kargom Nerede?", href: "/sayfa/kargo-takip" },
    { type: "link", icon: "📱", text: "Kampanyalar", href: "/sayfa/kampanya-detay", target: "_blank" }
  ]
};
