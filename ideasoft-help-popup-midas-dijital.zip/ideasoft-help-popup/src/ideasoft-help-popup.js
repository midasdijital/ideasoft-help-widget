/**
 * Midas Dijital - IdeaSoft Help Popup
 * Developed by Midas Dijital E-Ticaret Danışmanlık
 *
 * Özelleştirilebilir Vanilla JavaScript destek / yardım bileşeni.
 * IdeaSoft Özel Kod (Footer JS) alanında veya harici JS dosyası olarak kullanılabilir.
 *
 * Project: IdeaSoft Help Popup
 * Author: Midas Dijital E-Ticaret Danışmanlık
 * License: MIT
 */
(function () {
  "use strict";

  const DEFAULTS = {
    brandName: "Keyforia",
    title: "Keyforia Yardım Merkezi",
    subtitle: "Size nasıl yardımcı olabiliriz?",
    logoUrl: "",
    primaryColor: "#dc2237",
    primaryColorDark: "#b91327",
    whatsappNumber: "905322374529",
    bubbleText: "Nasıl yardımcı olabiliriz?",
    welcomeText: "Sipariş, kargo ve destek işlemlerinize hızlıca ulaşın.",
    bubbleDelay: 3000,
    bubbleDuration: 5000,
    desktop: { left: 24, bottom: 100, width: 340 },
    mobile: { left: 0, bottom: 95, width: 340, tabWidth: 42, tabHeight: 76 },
    excludedPaths: ["/sepet", "/sepet/"],
    actions: [
      { type: "whatsapp", icon: "💬", text: "WhatsApp Destek" },
      { type: "link", icon: "📦", text: "Kargom Nerede?", href: "/sayfa/kargo-takip" },
      { type: "link", icon: "📱", text: "Kampanyalar", href: "/sayfa/kampanya-detay", target: "_blank" }
    ]
  };

  const USER_CONFIG = window.IDEASOFT_HELP_POPUP_CONFIG || {};
  const config = deepMerge(DEFAULTS, USER_CONFIG);

  if (config.excludedPaths.includes(window.location.pathname)) return;
  if (document.querySelector(".ideasoft-help-popup")) return;

  injectStyle(config);
  createWidget(config);

  function deepMerge(base, override) {
    const output = { ...base };
    Object.keys(override || {}).forEach((key) => {
      if (override[key] && typeof override[key] === "object" && !Array.isArray(override[key])) {
        output[key] = deepMerge(base[key] || {}, override[key]);
      } else {
        output[key] = override[key];
      }
    });
    return output;
  }

  function createWidget(cfg) {
    const popup = document.createElement("div");
    popup.className = "ideasoft-help-popup minimized";

    const logo = cfg.logoUrl
      ? `<img src="${escapeHtml(cfg.logoUrl)}" alt="${escapeHtml(cfg.brandName)} logo">`
      : `<span class="ideasoft-help-fallback">${escapeHtml((cfg.brandName || "K").charAt(0))}</span>`;

    const actionsHtml = cfg.actions.map((item) => {
      const target = item.target === "_blank" ? ' target="_blank" rel="noopener noreferrer"' : "";
      const href = item.type === "whatsapp" ? "#" : escapeHtml(item.href || "#");
      const cls = item.type === "whatsapp" ? " ideasoft-help-whatsapp" : "";
      return `<a href="${href}" class="ideasoft-help-btn${cls}"${target}>
        <div class="ideasoft-help-btn-left">
          <div class="ideasoft-help-icon">${escapeHtml(item.icon || "•")}</div>
          <div class="ideasoft-help-text">${escapeHtml(item.text || "Bağlantı")}</div>
        </div>
        <div class="ideasoft-help-arrow">›</div>
      </a>`;
    }).join("");

    popup.innerHTML = `
      <div class="ideasoft-help-header">
        <div class="ideasoft-help-left">
          <div class="ideasoft-help-avatar">${logo}</div>
          <div class="ideasoft-help-head-copy">
            <div class="ideasoft-help-title">${escapeHtml(cfg.title)}</div>
            <div class="ideasoft-help-subtitle">${escapeHtml(cfg.subtitle)}</div>
          </div>
        </div>
        <button type="button" class="ideasoft-help-close" aria-label="Menüyü küçült">&times;</button>
      </div>
      <div class="ideasoft-help-bubble">${escapeHtml(cfg.bubbleText)}</div>
      <div class="ideasoft-help-body">
        <div class="ideasoft-help-message">${escapeHtml(cfg.welcomeText)}</div>
        <div class="ideasoft-help-actions">${actionsHtml}</div>
      </div>`;

    document.body.appendChild(popup);

    const logoImage = popup.querySelector(".ideasoft-help-avatar img");
    if (logoImage) {
      logoImage.addEventListener("error", function () {
        this.parentElement.innerHTML = `<span class="ideasoft-help-fallback">${escapeHtml((cfg.brandName || "K").charAt(0))}</span>`;
      });
    }

    popup.querySelector(".ideasoft-help-close").addEventListener("click", (e) => {
      e.stopPropagation();
      popup.classList.add("minimized");
      popup.classList.remove("bubble-visible");
    });

    popup.addEventListener("click", () => {
      if (popup.classList.contains("minimized")) {
        popup.classList.remove("bubble-visible");
        popup.classList.remove("minimized");
      }
    });

    const wa = popup.querySelector(".ideasoft-help-whatsapp");
    if (wa) {
      wa.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const message = encodeURIComponent(`Merhaba, ${cfg.brandName} web sitesinde şu sayfadayım:\n${window.location.href}\n\nYardım almak istiyorum.`);
        window.open(`https://wa.me/${cfg.whatsappNumber}?text=${message}`, "_blank", "noopener,noreferrer");
      });
    }

    setTimeout(() => {
      if (!popup.classList.contains("minimized")) return;
      popup.classList.add("bubble-visible");
      setTimeout(() => popup.classList.remove("bubble-visible"), cfg.bubbleDuration);
    }, cfg.bubbleDelay);
  }

  function injectStyle(cfg) {
    const style = document.createElement("style");
    style.textContent = `
      .ideasoft-help-popup,.ideasoft-help-popup *{box-sizing:border-box;font-family:Geist,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
      .ideasoft-help-popup{position:fixed;left:${cfg.desktop.left}px;bottom:${cfg.desktop.bottom}px;z-index:99999;width:${cfg.desktop.width}px;overflow:hidden;background:rgba(255,255,255,.98);border:1px solid rgba(17,24,39,.08);border-radius:22px;box-shadow:0 24px 65px rgba(17,24,39,.16),0 3px 12px rgba(17,24,39,.06);animation:ideasoft-open .22s ease-out}
      @keyframes ideasoft-open{from{opacity:0;transform:translateY(8px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}
      .ideasoft-help-header{position:relative;min-height:76px;padding:15px 16px;color:#fff;background:linear-gradient(135deg,${cfg.primaryColor},${cfg.primaryColorDark});display:flex;align-items:center;justify-content:space-between}
      .ideasoft-help-header:after{content:"";position:absolute;top:-48px;right:-35px;width:65px;height:65px;border-radius:50%;background:rgba(255,255,255,.09)}
      .ideasoft-help-left{position:relative;z-index:1;display:flex;align-items:center;gap:12px;min-width:0}.ideasoft-help-avatar{width:42px;height:42px;padding:6px;background:#fff;border-radius:13px;overflow:hidden;display:flex;align-items:center;justify-content:center;flex:0 0 auto}.ideasoft-help-avatar img{width:100%;height:100%;object-fit:contain}.ideasoft-help-fallback{color:${cfg.primaryColor};font-size:18px;font-weight:800}.ideasoft-help-title{font-size:14px;font-weight:700;line-height:1.25}.ideasoft-help-subtitle{margin-top:3px;font-size:11px;font-weight:500;opacity:.82}
      .ideasoft-help-close{position:relative;z-index:1;width:30px;height:30px;border:0;border-radius:10px;color:#fff;background:rgba(255,255,255,.13);font:400 21px/1 Arial;cursor:pointer}.ideasoft-help-body{padding:14px;background:#f8f9fb}.ideasoft-help-message{margin-bottom:11px;padding:12px 13px;color:#4b5563;background:#fff;border:1px solid #eceff3;border-radius:14px;font-size:12px;line-height:1.55}.ideasoft-help-actions{display:flex;flex-direction:column;gap:8px}.ideasoft-help-btn{width:100%;min-height:52px;padding:9px 11px;color:#111827!important;background:#fff;border:1px solid #eceff3;border-radius:14px;display:flex;align-items:center;justify-content:space-between;gap:10px;text-decoration:none!important}.ideasoft-help-btn-left{display:flex;align-items:center;gap:11px;min-width:0}.ideasoft-help-icon{width:34px;height:34px;border-radius:11px;color:${cfg.primaryColor};background:${hexToRgba(cfg.primaryColor,.08)};display:flex;align-items:center;justify-content:center}.ideasoft-help-text{font-size:12px;font-weight:650;color:#1f2937}.ideasoft-help-arrow{width:25px;height:25px;border-radius:8px;background:#f7f8fa;color:#9ca3af;display:flex;align-items:center;justify-content:center;font-size:17px}
      .ideasoft-help-bubble{position:absolute;left:72px;top:50%;z-index:2;min-height:44px;padding:0 17px;display:flex;align-items:center;color:#1f2937;background:#fff;border:1px solid #eceff3;border-radius:16px;box-shadow:0 12px 32px rgba(17,24,39,.15);font-size:13px;font-weight:650;white-space:nowrap;pointer-events:none;opacity:0;visibility:hidden;transform:translateY(-50%) translateX(-8px) scale(.96);transition:.22s ease}.ideasoft-help-bubble:before{content:"";position:absolute;left:-7px;top:50%;width:13px;height:13px;background:#fff;border-left:1px solid #eceff3;border-bottom:1px solid #eceff3;transform:translateY(-50%) rotate(45deg)}
      .ideasoft-help-popup.minimized{width:60px;height:60px;overflow:visible;background:transparent;border:0;border-radius:100px;box-shadow:none;cursor:pointer;animation:none}.ideasoft-help-popup.minimized .ideasoft-help-header{width:60px;min-height:60px;height:60px;padding:0;border-radius:100px;justify-content:center;box-shadow:none}.ideasoft-help-popup.minimized .ideasoft-help-avatar{width:59px;height:59px;padding:0;border-radius:100px}.ideasoft-help-popup.minimized .ideasoft-help-head-copy,.ideasoft-help-popup.minimized .ideasoft-help-close,.ideasoft-help-popup.minimized .ideasoft-help-body{display:none}.ideasoft-help-popup.minimized.bubble-visible .ideasoft-help-bubble{opacity:1;visibility:visible;transform:translateY(-50%) translateX(0) scale(1)}
      @media(max-width:768px){.ideasoft-help-popup{left:10px;right:auto;bottom:${cfg.mobile.bottom}px;width:calc(100vw - 20px);max-width:${cfg.mobile.width}px}.ideasoft-help-popup.minimized{left:0;bottom:${cfg.mobile.bottom}px;width:${cfg.mobile.tabWidth}px;height:${cfg.mobile.tabHeight}px;border-radius:0 16px 16px 0}.ideasoft-help-popup.minimized .ideasoft-help-header{width:${cfg.mobile.tabWidth}px;height:${cfg.mobile.tabHeight}px;min-height:${cfg.mobile.tabHeight}px;border-radius:0 16px 16px 0;background:linear-gradient(160deg,${cfg.primaryColor},${cfg.primaryColorDark});box-shadow:4px 5px 16px rgba(17,24,39,.14)}.ideasoft-help-popup.minimized .ideasoft-help-avatar{width:32px;height:32px;padding:2px;border-radius:10px}.ideasoft-help-popup.minimized .ideasoft-help-avatar img{border-radius:8px}.ideasoft-help-bubble{left:52px;max-width:calc(100vw - 70px);min-height:38px;padding:0 13px;border-radius:12px;font-size:11px;box-shadow:0 7px 20px rgba(17,24,39,.12);white-space:nowrap}.ideasoft-help-bubble:before{left:-6px;width:11px;height:11px}}
    `;
    document.head.appendChild(style);
  }

  function hexToRgba(hex, alpha) {
    const value = hex.replace("#", "");
    const bigint = parseInt(value.length === 3 ? value.split("").map(x => x + x).join("") : value, 16);
    const r = (bigint >> 16) & 255, g = (bigint >> 8) & 255, b = bigint & 255;
    return `rgba(${r},${g},${b},${alpha})`;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, (char) => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#039;","\"":"&quot;"}[char]));
  }
})();
